package csc2a.acsse.model;

public interface IDesignVisitor {

	void visits();
}
