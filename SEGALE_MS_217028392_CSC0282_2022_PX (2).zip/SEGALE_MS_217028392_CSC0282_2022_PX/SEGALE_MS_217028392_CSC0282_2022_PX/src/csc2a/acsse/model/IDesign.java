package csc2a.acsse.model;

public interface IDesign {

	void accepts(IDesign Visitor);
}
